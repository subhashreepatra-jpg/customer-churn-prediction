
CUSTOMER CHURN PREDICTION USING MACHINE LEARNING

Project Overview:
This project analyzes customer data and predicts whether a customer is likely to churn.

Dataset:
Customer banking data containing demographic, account and activity information.

Key Findings:
- Overall churn rate: 20.37%
- Female churn rate: 25.07%
- Male churn rate: 16.40%
- Germany churn rate: 32.44%
- Highest age-group churn: 51-60 (56.21%)
- Lowest age-group churn: 18-30 (7.50%)

Machine Learning Model:
Random Forest Classifier

Model Performance:
- Accuracy: 86.35%
- AUC Score: 0.85

Most Important Feature:
Age

Conclusion:
The model can identify patterns associated with customer churn and can help
banks identify customers who may be at higher risk of leaving.
